<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = $_POST['nim'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $conn = db_connect();
    $stmt = $conn->prepare("INSERT INTO pengguna (nim, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $nim, $password);
    if ($stmt->execute()) {
        header("location: login.php");
    } else {
        echo "Terjadi kesalahan. Silakan coba lagi.";
    }
}
?>

<form method="post">
    NIM: <input type="text" name="nim" required>
    Password: <input type="password" name="password" required>
    <input type="submit" value="Daftar">
</form>
