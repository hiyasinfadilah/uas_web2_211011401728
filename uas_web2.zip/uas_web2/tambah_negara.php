<?php
require_once 'db.php';
if (!isset($_SESSION['nim'])) {
    header("location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grup_id = $_POST['grup_id'];
    $nama_negara = $_POST['nama_negara'];
    $menang = $_POST['menang'];
    $seri = $_POST['seri'];
    $kalah = $_POST['kalah'];
    $poin = ($menang * 3) + ($seri);

    $conn = db_connect();
    $stmt = $conn->prepare("INSERT INTO negara (grup_id, nama_negara, menang, seri, kalah, poin) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isiiii", $grup_id, $nama_negara, $menang, $seri, $kalah, $poin);

    if ($stmt->execute()) {
        header("location: dashboard.php");
    } else {
        echo "Terjadi kesalahan. Silakan coba lagi.";
    }
}

$conn = db_connect();
$result = $conn->query("SELECT id, nama_grup FROM grup");
?>

<form method="post">
    Grup: 
    <select name="grup_id">
        <?php while ($row = $result->fetch_assoc()): ?>
        <option value="<?php echo $row['id']; ?>"><?php echo $row['nama_grup']; ?></option>
        <?php endwhile; ?>
    </select>
    Nama Negara: <input type="text" name="nama_negara" required>
    Menang: <input type="number" name="menang" required>
    Seri: <input type="number" name="seri" required>
    Kalah: <input type="number" name="kalah" required>
    Poin: <input type="number" name="poin" required>
    <input type="submit" value="Tambah Negara">
</form>
