<?php
session_start();
ob_start(); // Memulai buffer output

require_once 'config.php'; // Ini akan include db.php juga melalui config.php
require('fpdf/fpdf.php');

if (!isset($_SESSION['nim'])) {
    header("location: login.php");
    exit;
}

$nim = $_SESSION['nim']; // Mengambil NIM dari sesi

// Menghubungkan ke database
$conn = db_connect();
$result = $conn->query("SELECT g.nama_grup, n.nama_negara, n.menang, n.seri, n.kalah, n.poin FROM negara n JOIN grup g ON n.grup_id = g.id WHERE g.nama_grup = 'Group A'");

// Membuat instance FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Menambahkan judul laporan
$pdf->Cell(0, 10, 'Data Group A', 0, 1, 'C');
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 10, 'Per ' . date('d F Y H:i:s'), 0, 1, 'C'); // Menampilkan tanggal dan waktu sekarang
$pdf->Cell(0, 10, 'NIM: ' . $nim, 0, 1, 'C'); // Menampilkan NIM pengguna
$pdf->Ln(10); // Menambah jarak kosong

// Menambahkan header tabel
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(30, 10, 'Grup', 1);
$pdf->Cell(50, 10, 'Negara', 1);
$pdf->Cell(20, 10, 'Menang', 1);
$pdf->Cell(20, 10, 'Seri', 1);
$pdf->Cell(20, 10, 'Kalah', 1);
$pdf->Cell(20, 10, 'Poin', 1);
$pdf->Ln();

// Mengisi tabel dengan data dari database
$pdf->SetFont('Arial', '', 12);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(30, 10, $row['nama_grup'], 1);
    $pdf->Cell(50, 10, $row['nama_negara'], 1);
    $pdf->Cell(20, 10, $row['menang'], 1);
    $pdf->Cell(20, 10, $row['seri'], 1);
    $pdf->Cell(20, 10, $row['kalah'], 1);
    $pdf->Cell(20, 10, $row['poin'], 1);
    $pdf->Ln();
}

// Menghasilkan file PDF
$pdf->Output();
ob_end_flush(); // Mengakhiri buffer output dan mengirim output
?>
