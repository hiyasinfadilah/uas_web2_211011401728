<?php
require_once 'db.php';
require('fpdf/fpdf.php'); // Pastikan jalur ini benar

if (!isset($_SESSION['nim'])) {
    header("location: login.php");
    exit;
}

$conn = db_connect();
$result = $conn->query("SELECT g.nama_grup, n.nama_negara, n.menang, n.seri, n.kalah, n.poin FROM negara n JOIN grup g ON n.grup_id = g.id");

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

$pdf->Cell(30, 10, 'Grup');
$pdf->Cell(50, 10, 'Negara');
$pdf->Cell(20, 10, 'Menang');
$pdf->Cell(20, 10, 'Seri');
$pdf->Cell(20, 10, 'Kalah');
$pdf->Cell(20, 10, 'Poin');
$pdf->Ln();

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(30, 10, $row['nama_grup']);
    $pdf->Cell(50, 10, $row['nama_negara']);
    $pdf->Cell(20, 10, $row['menang']);
    $pdf->Cell(20, 10, $row['seri']);
    $pdf->Cell(20, 10, $row['kalah']);
    $pdf->Cell(20, 10, $row['poin']);
    $pdf->Ln();
}

$pdf->Output();
?>
