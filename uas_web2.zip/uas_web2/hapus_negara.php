<?php
require_once 'db.php';
if (!isset($_SESSION['nim'])) {
    header("location: login.php");
    exit;
}

$id = $_GET['id'];
$conn = db_connect();
$stmt = $conn->prepare("DELETE FROM negara WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("location: dashboard.php");
?>
