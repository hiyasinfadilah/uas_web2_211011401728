<?php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = $_POST['nim'];
    $password = $_POST['password'];
    
    $conn = db_connect();
    $stmt = $conn->prepare("SELECT id, password FROM pengguna WHERE nim = ?");
    $stmt->bind_param("s", $nim);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['nim'] = $nim;
            header("location: dashboard.php");
        } else {
            echo "Password salah.";
        }
    } else {
        echo "Akun dengan NIM tersebut tidak ditemukan.";
    }
}
?>

<form method="post">
    NIM: <input type="text" name="nim" required>
    Password: <input type="password" name="password" required>
    <input type="submit" value="Masuk">
</form>
<p>Belum punya akun? <a href="register.php">Daftar di sini</a>.</p>
