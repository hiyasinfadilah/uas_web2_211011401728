<?php
require_once 'db.php';
if (!isset($_SESSION['nim'])) {
    header("location: login.php");
    exit;
}

$id = $_GET['id'];
$conn = db_connect();
$result = $conn->query("SELECT * FROM negara WHERE id = $id");
$negara = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grup_id = $_POST['grup_id'];
    $nama_negara = $_POST['nama_negara'];
    $menang = $_POST['menang'];
    $seri = $_POST['seri'];
    $kalah = $_POST['kalah'];
    $poin = ($menang * 3) + ($seri);

    $stmt = $conn->prepare("UPDATE negara SET grup_id = ?, nama_negara = ?, menang = ?, seri = ?, kalah = ?, poin = ? WHERE id = ?");
    $stmt->bind_param("isiiiii", $grup_id, $nama_negara, $menang, $seri, $kalah, $poin, $id);
    $stmt->execute();
    header("location: dashboard.php");
}
?>

<form method="post">
    Grup: 
    <select name="grup_id">
        <option value="1" <?php if($negara['grup_id'] == 1) echo 'selected'; ?>>A</option>
        <option value="2" <?php if($negara['grup_id'] == 2) echo 'selected'; ?>>B</option>
        <option value="3" <?php if($negara['grup_id'] == 3) echo 'selected'; ?>>C</option>
        <option value="4" <?php if($negara['grup_id'] == 4) echo 'selected'; ?>>D</option>
    </select>
    Nama Negara: <input type="text" name="nama_negara" value="<?php echo $negara['nama_negara']; ?>" required>
    Menang: <input type="number" name="menang" value="<?php echo $negara['menang']; ?>" required>
    Seri: <input type="number" name="seri" value="<?php echo $negara['seri']; ?>" required>
    Kalah: <input type="number" name="kalah" value="<?php echo $negara['kalah']; ?>" required>
    Poin: <input type="number" name="poin" value="<?php echo $negara['poin']; ?>" required>
    <input type="submit" value="Update Negara">
</form>
